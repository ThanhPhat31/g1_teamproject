/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.db.DBConnection;

import entity.Account;
import entity.Product;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LUANVS-CE160860
 */
public class DAO {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public List<Product> getAll() {
        List<Product> list = new ArrayList<>();
        String query = "select * from product";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query); // nem cau lenh query sang sql
            rs = ps.executeQuery();// chay cau lenh query nhan ket qua tra ve
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getInt(7))
                );

            }
        } catch (Exception e) {
        }
        return list;
    }

    public static void main(String[] args) {
        DAO dao = new DAO();
        List<Product> list = dao.getAll();
        for (Product o : list) {
            System.out.println(o);
        }
    }

    public Product getLast() {
        String query = "select top 1 * from product\n"
                + "order by id desc";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query); // nem cau lenh query sang sql
            rs = ps.executeQuery();// chay cau lenh query nhan ket qua tra ve
            while (rs.next()) {
                return new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getInt(7));

            }
        } catch (Exception e) {
        }
        return null;
    }

    public Account forgetpass(String Account, String Password) {
        String query = "UPDATE account\n"
                + "SET Password = ? \n"
                + "where Account  = ?";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query); // nem cau lenh query sang sql
//            rs = ps.executeQuery();// chay cau lenh query nhan ket qua tra ve
            ps.setString(1, Password);
            ps.setString(2, Account);

            ps.executeUpdate();
        } catch (Exception e) {

        }
        return null;

    }

    public void change(Account a) {
        String query = "UPDATE account\n"
                + "SET Password = ? \n"
                + "where Account  = ?";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query); // nem cau lenh query sang sql
//            rs = ps.executeQuery();// chay cau lenh query nhan ket qua tra ve
            ps.setString(1, a.getPassword());
            ps.setString(2, a.getAccount());

            ps.executeUpdate();
        } catch (Exception e) {

        }

    }

    public Account check(String Account, String opass) {
        String query = "select * from account where Account=? and Password=?";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query); // nem cau lenh query sang sql
//            rs = ps.executeQuery();// chay cau lenh query nhan ket qua tra ve
            ps.setString(1, Account);
            ps.setString(2, opass);

            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(Account, opass, rs.getInt("Role")
                );

            }
        } catch (Exception e) {

        }
        return null;
    }

    public Account login(String Account, String Password) {

        String query = "select * from account\n"
                + "where Account = ?\n"
                + "and Password = ?";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, Account);
            ps.setString(2, Password);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3));

            }

        } catch (Exception e) {
        }
        return null;
    }

    public Account check(String Account) {
        String query = "select * from account\n"
                + "where Account = ?\n";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, Account);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3)
                );

            }
        } catch (Exception e) {
        }
        return null;
    }

    public void signup(String Account, String Password) {
        String query = "insert into account\n"
                + "values(?,?,0)";
        try {
            conn = new DBConnection().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, Account);
            ps.setString(2, Password);
//            rs = ps.executeQuery(); // sai  vi khong co bang result
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
}
