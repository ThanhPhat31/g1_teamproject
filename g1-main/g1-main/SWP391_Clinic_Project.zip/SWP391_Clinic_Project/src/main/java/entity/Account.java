    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author vusyl
 */
public class Account {

   private String Account;
   private String Password ;
   private int Role;


    public Account() {
    }

    public Account(String Account, String Password, int Role) {
        this.Account = Account;
        this.Password = Password;
        this.Role = Role;
    }

   

    public String getAccount() {
        return Account;
    }

    public void setAccount(String Account) {
        this.Account = Account;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getRole() {
        return Role;
    }

    public void setRole(int Role) {
        this.Role = Role;
    }

    @Override
    public String toString() {
        return "Account{" + "Account=" + Account + ", Password=" + Password + ", Role=" + Role + '}';
    }



  

    
    
}
